
window.onload = init;




function init()
{
	var canvas = document.getElementById("square");

	if (typeof canvas.getContext != "undefined")
	{
		var context = canvas.getContext("2d");
		context.fillStyle = "#0066CC";
		context.fillRect(0, 0, 400, 400);
		context.clearRect(75, 75, 250, 250);
		context.strokeStyle = "#FF0000";
		context.strokeRect(150, 150, 100, 100);
	}
};